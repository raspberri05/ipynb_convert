def add(num):
  return num + 1